from helpers.algo import boundary, neighbours

# print(algo)
# boundary.find_new_hex_loc(1, 'a')

# neighbours.find_new_hex_neighbours([0,0,0], 0)